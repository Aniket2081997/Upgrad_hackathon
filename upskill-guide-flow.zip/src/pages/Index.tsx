import Dashboard from "@/components/Dashboard";

const Index = () => {
  return <Dashboard />;
};

export default Index;
